package cib.learning.rabbit2file

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Rabbit2fileApplicationTests {

    @Test
    fun contextLoads() {
    }

}
