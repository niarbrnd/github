package cib.learning.rabbit2file

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.ImportResource
import org.springframework.integration.config.EnableIntegration

@SpringBootApplication
@ImportResource("appConfigRabbit2File.xml")
@EnableIntegration
class Rabbit2fileApplication

fun main(args: Array<String>) {
    runApplication<Rabbit2fileApplication>(*args)
}
