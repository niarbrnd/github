package Cib.learning.Service;

public class db2object {
}
