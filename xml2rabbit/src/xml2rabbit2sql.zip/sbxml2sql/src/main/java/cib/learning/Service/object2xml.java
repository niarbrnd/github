package Cib.learning.Service;

public class object2xml {
}
