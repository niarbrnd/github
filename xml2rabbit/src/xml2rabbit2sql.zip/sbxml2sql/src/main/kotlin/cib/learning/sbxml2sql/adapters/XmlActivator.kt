package cib.learning.sbxml2sql.adapters

//@Configuration
//@EnableIntegration
class XmlActivator {
   /* @ServiceActivator(inputChannel = "fileInputChannel")
    fun adjustRevenue(order: Message<*>): Message<File> {
        println("Processing file")
        println("Done processing file")
        return order
    }

    */
}
