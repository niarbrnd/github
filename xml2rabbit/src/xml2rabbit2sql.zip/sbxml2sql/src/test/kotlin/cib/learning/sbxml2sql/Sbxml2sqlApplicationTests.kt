package cib.learning.sbxml2sql

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Sbxml2sqlApplicationTests {

    @Test
    fun contextLoads() {
    }

}
