package cib.learning.rabbit2sql

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Rabbit2sqlApplicationTests {

    @Test
    fun contextLoads() {
    }

}
