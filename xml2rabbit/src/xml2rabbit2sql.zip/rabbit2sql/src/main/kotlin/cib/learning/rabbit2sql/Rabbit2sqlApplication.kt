package cib.learning.rabbit2sql

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Rabbit2sqlApplication

fun main(args: Array<String>) {
    runApplication<Rabbit2sqlApplication>(*args)
}
